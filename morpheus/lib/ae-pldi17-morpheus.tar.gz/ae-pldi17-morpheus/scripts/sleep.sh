#!/bin/bash

sleep $1
echo TIMEOUT > /tmp/morpheus5.tmp

